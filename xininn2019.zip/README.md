# 馨客栈

> 馨客栈导航已经陪伴大家有好几个年头了，基本上我的初衷是这样的   
> 每一年改版一次   
> 每个月优化多次   
> 持续不断的更新迭代，尽我所能的把最好的体验展现给各位栈友们
> 经过了半年的不懈努力，今年的馨客栈官网已经全部正式完工了哈，栈友们好好享受哈   

**[馨客栈导航](http://mackxin.com/nav.html)**

**[馨客栈前端导航](http://mackxin.com/webnav.html)**

**[馨客栈每日分享](http://mackxin.com/fx.html)**

**[馨客栈更新计划](http://mackxin.com/update.html)**

**[馨客栈电商导航](http://mackxin.com/dianshang.html)**

**[馨客栈设计导航](http://mackxin.com/sheji.html)**

**[馨客栈破冰导航](http://mackxin.com/pobing.html)**

**[馨客栈情报局](http://mackxin.com/qingbaoju.html)**

2019.02.19 馨客栈2019版全新的导航站，还在持续的更新中

2019.06.10 馨客栈今年的网站基本成型，下半年基本就是维护更新优化了，栈友须知哈

2019.07.02 近期发现有仿我网站的特殊网站出现，还是大量出现

