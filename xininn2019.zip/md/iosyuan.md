# 苹果源

## ios软件源

[apt.so/ios6vx](ios6五百年源)

[apt.feng/eq2wow](ios6分享源)

[apt.so/mksscc](MK越狱源)

[apt.so/anyinkeji](盗版暗影)

[apt.so/tanyao](杀手源)

[apt.so/anyinkj](正版暗影)

[apt.so/10444296](梦魇源)

[yuan.duowan.com](多玩中文源)

[apt.so/zb24k001](24k1.0版源)

[apt.so/zb24kk](24k2.0版)

[apt.so/hx8888](HX源)

[apt.so/yizeruier](变态微商)

[apt.feng.com](威锋源)

[repo.weiphone.com](威锋精品源)

[apt.so/9530634](度爷源)

[repo.hackyouriphone.org](国外知名破解软件源)

[cydia.china3gpp.com](卡贴补丁源)

[apt.so/ztooogg](喜源)

[apt.3kzhushou.com](3K助手源)

[exile90software.com/cydia](iCleanerPro官方源)

[iphone.tgbus.com/cydia](电玩巴士源)

[apt.zntx.cc](八门神器官方源)

[apt.uuhelper.com](UU助手官方源)

[apt.xxzhushou.com](XX助手官方源)

[repo.iapfree.org](IAPFree官方源)

[system.in-appstore.com/repo](LocalIAPstore官方源)

[rpetri.ch/repo](Activator官方源)

[cydia.clezz.com](Quickdo官方源)

[cydia.bitesms.com](Bitesms官方源)

[getdelta.co](Flex官方源)

[repo.alexzielenski.com](Zeppelin官方源)

[deb.danstaface.net](vWallpaper官方源)

[apt.abcydia.com](雷锋源)

[jonxbk.com/cydia](星巴客)

[apt.so/ios8phone](交流地带吧)

[14kcydia.cc](狮子源)

[cydiavip.com](app越狱推送)

[apt.cydiaba.cn](贴吧源)

[apt.hackcn.net](黑客源)

[iosxin.cc](iosxin源)

[apt.cydia.so:88](JK中文源)

[julio.xarold.com](cydown官方源)

[cydia.ppsspp.org](ppsspp模拟器)

[apt.cydiario.cc](rio源)

[apt.sunbelife.com](S中文源)

[repo.xarold.com](国外破解)

[apt.xyzs.com](xy助手)

[apt.tongbu.com](同步推)

[apt.wxhbts.com](多米诺骨牌)

[apt.so/dashuibi](大水逼)

[apt.so/zhuyuliang](宅猪猪)

[apt.so/hongvyc](红V)

[apt.so/ye353502117](罗源)

[cydialmg.cc](零秒哥)

[apt.so/zb24k001](麦丁科技)

[apt.so/hbs520](脑残酸菜面)

[apt.cydiario.cc](Rio源)

[apt.cydios.cc](Apple越狱狮源)

[apt.wxbls.cn](BLS/布鲁斯源)

[apt.so/aptnjzy](威锋宁静之雨源)

[cydia.angelxwind.net](蔡明美源)

[apt.25pp.com](pp助手)

[aptso.cn](八木中文源)

[apt.xxzhushou.com](XX助手官方源)

[apt.abcydia.com](雷锋源)

[jonxbk.com/cydia](星巴客)

[14kcydia.cc](狮子源)

[cydiavip.com](app越狱推送)

[apt.cydiaba.cn](贴吧源)

[iosxin.cc](iosxin源)

[cydialmg.cc](零秒哥)

[apt.cydios.cc](Apple越狱狮源)

[apt.wxbls.cn](BLS/布鲁斯源)

[apt.appbs.cn/](AA团队)

[appap.cc/](app插件推送站)

[52app.cc/](有玩科技)

[88439156.cc/](懒猫科技)

[47.95.241.34/](顶峰科技)

[cydialonge.cc/](龙哥)

[cydia.kkwen.com/](红包神探)

[apt.iocydia.cn](cydia越狱源)

[cydiami.cn/](apple越狱插件源)

[apt.touchsprite.com](触动精灵)

[apt.cydiami.com](蜜蜂源)

[apt.keevi.cc](keevi源)

[apt.iphoneba.cn](知网少年)

[h.933k.cn/](93嗨客源)

[Mrmadtw.github.io/repo](MrmadRepo)

[ibreak.yourepo.com](ibak源)

[netskao.cn/repo](BY哥哥源)

[aquawu.github.io/igg](igg)

[apt.25mao.com](老猫)

> 让老机型实现 iPhone X 手势操作和界面的插件 HomeGesture 测试兼容至 iOS 12.1.2 [源地址](https://repo.dynastic.co/) 
> 如果在安装过程中遇到 com.spark.libsparkapplist 依赖缺失，只需要添加 [源地址](https://repo.packix.com/)

> FloatyDock 插件可以让 iPhone 实现和 iPad 一样的 Dock 栏风格 测试兼容至 iOS 12.1.2 自带 BigBoss 源就能下载 ​​​​

> 最近很多小伙伴私信问如何解除 iOS 12 的越狱环境恢复出厂设置，可以使用 unc0ver 回到最初的无越狱系统快照环境：
> 重启手机后打开 unc0ver-Settings，将【Restore RootFS (rec0ver)】打开，最后点击【Jailbreak】即可

> 强烈推荐安装 Cydia 的功能增强插件 SwipeForMore 安装之后左滑 Cydia 里的插件就可以呼出【列表安装/卸载】等功能，
> 有效解决插件每次安装或卸载都需要注销一次的繁琐过程 只需在设置里将 SwipeForMore 的 Use icons 开关关闭即可中文显示自带 BigBoss 就能下载，兼容至 iOS 12.1.2

> 不一样的音量调节弹窗插件 VideoHUD 更新兼容性至 iOS 12.1.2 自带 BigBoss 源就能下载 ​​​​

> SugarCane 插件可以使控制中心里的亮度和音量条百分比显示 测试兼容至 iOS 12.1.2[源地址](https://repo.packix.com/)

> ClearBadges3DTouch10 插件可以通过 3D Touch 功能呼出【Clear Badge Notifications】按钮，清理应用角标通知 测试兼容至 iOS 12.1.2自带 BigBoss 源就能下载

> iOS12 状态栏 自定义网标文字
> Safari Plus 插件

> ForceInPicture 插件开启浏览器视频画中画功能，测试兼容至 iOS 12.1.2 自带 BigBoss 源就能下载

> Electra 越狱工具推出的新版插件商店 Sileo 现在可以通过 [下载地址](https://app.ignition.fun/) 在线安装到 iOS 11-12.2 beta 3 非越狱设备上了 当然只有越狱之后才能安装里面的插件 其他只能看看

> 每次越狱必装的 Cydown 插件测试已经兼容至 iOS 12.1.2有了它就可以免费下载 Cydia 里的收费插件，还可以提取插件的 DEB 安装包等 [作者源地址](http://julio.xarold.com/)

> 如果使用了 unc0ver 越狱工具误装了不兼容的插件，导致注销后无限菊花，可先强制重启设备，再进入 unc0ver，将底部 Settings 里的 Load Tweaks 关闭，
> 再重新点击 Jailbreak 激活越狱环境，激活后进入 Cydia 卸载不兼容的插件，卸载后即可重新打开 Load Tweaks 激活越狱环境让其他插件生效

> Cydia 插件卸载教程：
> 1. 打开 Cydia
> 2. 点击底部菜单栏的【已安装】
> 3. 点击需要卸载的插件，右上角卸载
> 4. 卸载完成后【重启 SpringBoard】注销
> 注意：部分特殊插件可能需要重启设备，重启之后一定要回到越狱工具里，点击 Jailbreak 激活越狱环境

> GstureX X手势风格  这个是模仿iphonex手势动作的
> BetterCCXI 控制中心增强

> 越狱后支付宝打不开 微信不能刷脸支付等问题， 雷锋源下载Liberty Lite 屏蔽越狱检测插件 
> 别的屏蔽插件都不行，只有这个可以，不知道为什么


