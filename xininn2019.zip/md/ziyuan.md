# 这里分享一些网上找的资源

```
2019-03-09,开始这个页面资源的开篇，不定期分享一些资源
2019-03-16,例行更新
```

## 如果链接失效什么的话，不要找我，我也没有备份的哈

## 2019-03-09

> 199元 许岑讲的PPT提升课   
> 此教程适合以下人群：   
> 1.具备基础PPT技能，不靠模板不能做PPT星人(也就是用模板就能做“好”PPT的人)。   
> 2.只用keynote或PowerPoint，想了解另一工具的基本情况的人。   
> 3.想知道许岑是个什么样的人的人。   
> [链接地址](https://pan.baidu.com/s/1DBs-ikpe3gWH6zkvZX-QIQ) 提取码:   **5ecj**

> 珠峰培训前端2018全套视频   
> 这款软件是一款非常不错的前端学习课程，里面的内容是非常的丰富，包含了多个不同的课程，可以非常方便的让大家进行学习！   
> [链接地址](https://pan.baidu.com/wap/init?surl=cQ0lHcZXNJbKqwcn9WAQCQ) 提取码: **j3gf**

> PPT制作动画视频教程   
> 上面是视频截图，大家可以参考下。   
> [下载地址](https://pan.baidu.com/s/13dR44d_8p16c13_StVnVFw)

> 20节课零基础学photoshop   
> [下载地址](https://pan.baidu.com/s/1ntxz4e-ZlDCtnvSs443mew) 提取码: **2ggt**

> 某宝买的10000份网站模板打包   
> [下载地址](https://pan.baidu.com/s/1gb8CYl3dC4sw_emU85uePg)

> 零基础学习化妆术教程 小白几周变女王   
> 这个教程是关于化妆的教程，参加之后可以让你几周可以变身女王，教程包含的方面是非常之多的，每一点都详细的说出来了，如果你对于这个感兴趣的话就可以看看！   
> [下载地址](https://pan.baidu.com/wap/init?surl=4vkSr3HPbQ6i4qvFDipL4Q) 提取码: **6rrc**

> SegmentFault Vue技术栈开发实战 (26课时)   
> [下载地址](https://pan.baidu.com/s/1trSkspc1jqJFWnQNeCV96A) 提取码: **hj7a**

> 998元中国百家名企兴衰录   
> [下载地址](https://pan.baidu.com/s/1V8EY8hGdH2h6FYeEuATvTQ) 提取码: **twtj**

> 专业的PR视频剪辑教程 全系列课程   
> 课程目录：   
> 第0课：《Pr通关秘籍》   
> 第1课：电子相册案例-快速带你走进剪辑的世界   
> 第2课：视频片段混剪—你必须掌握的剪辑基本功   
> 第3课：个人宣传片-小白到高手的蜕变   
> 第4课：企业微课制作-下一个制片人就是你   
> 第5课：玩转PR特效-综艺级节目是怎样炼成的   
> 第6课：剪辑魔术-赞爆你朋友圈的创意视频   
> 第7课：绿幕抠图-为你的想象插上翅膀第8课：大师珍藏篇   
> [下载地址](https://pan.baidu.com/s/1V6rWxpq0a1VjDWLHMY6HEg)

> 旧照片修复ps视频教程 破损老照片翻新ps方法   
> [下载地址](https://pan.baidu.com/s/1fucf-WXJZBN2zDCAbRCCeg)

> 日本深夜食堂无删减版本分享   
> 1—4季无删减高清版本，喜欢的转存一份    
> [下载地址](https://pan.baidu.com/s/119yL7McETgOrWvGnD5lHoQ) 提取码：**hztf**    
> [下载地址](https://pan.baidu.com/s/1R1IL7NlXWrQ9bWqsfoJYZA)   

> 坚果Pro2 ROM分享   
> [下载地址](https://pan.baidu.com/s/1QiBQv4zDfyUb9lqW0D3KOA)   


## 2019-03-16


> 私房电子相册制作软件(旗舰版)   
> [下载链接](https://pan.baidu.com/s/1Ikq2P--GBVeWEebxKpsimA)    
> 提取码：8sw8   

> ps教程 站酷高高手合集   
> [下载链接](https://pan.baidu.com/s/18Y_v8CfQBYbdX2qFvuC6Xw)   
> 提取密码：elmx   

> baidu文档下载账号    
> [网站](http://www.blpack.com/)   
> 账号：343722874    
> 密码：546031   
> 在上面复制文档连接就好。还有2900财富值，先到先得

> 共享个字体网站的帐号   
> [字库网](http://www.zku.net/)   
> 帐号：17199970014   
> 密码：123321a    
> 里面有几百万积分

> 雅客Excel 36节课 轻松实现小白到高手的进阶
> [下载链接](https://pan.baidu.com/s/1240G7H56xNSjSz3xgLaApA) 
> 提取码：t0z0 

> Adobe Premiere Pro CC 2018视频学习教程和素材   
> [下载链接](https://pan.baidu.com/s/1NIBEd88alT62tetqVhNbkg)    
> 密码:q582

> ppt课程，《我懂个p，超人气课程》    
> [下载链接](https://pan.baidu.com/s/1CWUqucj2m0lA7VIZseURRQ)       
> 提取码：nzky 

> 电脑版谷歌翻译客户端   
> [官方网址](https://hypercube.top/copytranslator/)   
> [下载链接](https://pan.baidu.com/s/1ICe_OQNnUW2KR2CtjN0k6g)    
> 提取码：1t3k

> windows软件卸载神器最新版本Revo Uninstaller Pro4.05   
> [下载地址](http://t.cn/EIuODiP)

> 2019电脑版初级会计题库软件   
> [下载链接](https://pan.baidu.com/s/1eLg6qNG3qLatvCV7zSi4XQ)    
> 提取码 vwog

> 万兴PDF编辑器Wondershare PDFelement v6.8.8.4159中文破解   
> [下载链接](http://t.cn/EfVsF5N)

> 驾校科目一、科目四理论模拟考试系统   
> [下载链接](https://www.lanzous.com/i3fve1e)