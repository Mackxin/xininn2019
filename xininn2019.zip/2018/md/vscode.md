# VScode 插件介绍
---
### 软件设置为中文的插件 Chinese (Simplified) Language Pack for Visual Studio Code   
下载好后自动安装，然后重启你的编辑器就好了

### Code Blue   
> 是一个漂亮的 VS Code 暗色主题，由一种微妙的蓝色和其他颜色组成，容易识别，眼镜舒服，非常适合敲代码

### Path Intellisense   
> 自动补全路径

### beautify   
> 格式化代码

### colorize   
> 可视化颜色

### 